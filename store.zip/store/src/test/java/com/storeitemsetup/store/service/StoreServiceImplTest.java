package com.storeitemsetup.store.service;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Date;

import org.junit.Test;

import com.cts.store.controller.StoreNotFoundException;
import com.cts.store.entity.Store;
import com.cts.store.controller.StoreNotFoundException;
import com.cts.store.entity.Store;
import com.cts.store.service.StoreServiceImpl;

public class StoreServiceImplTest {

	StoreServiceImpl storeserviceimpl = mock(StoreServiceImpl.class);
	
	@Test
	public void testcreateStoreWithStore() {
		Store store = new Store();
		store.setStoreNumber(1L);
		store.setStoreName("Favorite Store");
		store.setStorePattern("S01");
		store.setStoreLocation("Solaialaghupuram");
		store.setState("Tamil Nadu");
		store.setCity("Madurai");
		store.setPinCode(625011L);
		store.setStoreOpeningTime("10:00");
		store.setStoreClosingTime("22:00");
		
		when(storeserviceimpl.createStore(store)).thenReturn("created");
		assertEquals(storeserviceimpl.createStore(store),"created");
	}
	
	@Test(expected=StoreNotFoundException.class)
	public void testcreateStoreWithNull() {
		Store st=null;
		
		when(storeserviceimpl.createStore(st)).thenThrow(new StoreNotFoundException("store cannot be created"));
		assertEquals(storeserviceimpl.createStore(st),"Store cannot be created");
	}

	@Test
	public void testupdateStoreWithStore() {
		Store store = new Store();
		store.setStoreNumber(1L);
		store.setStoreName("Favorite Store");
		store.setStorePattern("S01");
		store.setStoreLocation("Solaialaghupuram");
		store.setState("Tamil Nadu");
		store.setCity("Madurai");
		store.setPinCode(625011L);
		store.setStoreOpeningTime("10:00");
		store.setStoreClosingTime("22:00");
		
		when(storeserviceimpl.updateStore(store)).thenReturn("updated");
		assertEquals(storeserviceimpl.updateStore(store),"updated");
	}
	
	@Test(expected=StoreNotFoundException.class)
	public void testupdateStoreWithNull() {
		Store st=null;
		when(storeserviceimpl.updateStore(st)).thenThrow(new StoreNotFoundException("store cannot be updated"));
		assertEquals(storeserviceimpl.updateStore(st),"store cannot be created");
	}
	
	@Test(expected=StoreNotFoundException.class)
	public void testupdateStoreWithInvalidId() {
		Store st=new Store();
		st.setStoreNumber(2L);
		when(storeserviceimpl.updateStore(st)).thenThrow(new StoreNotFoundException("store cannot be updated"));
		assertEquals(storeserviceimpl.updateStore(st),"store cannot be created");
	}
	
	@Test
	public void testdeleteStoreWithStore() {
	    long id=1L;
		when(storeserviceimpl.deleteStore(id)).thenReturn("deleted");
		assertEquals(storeserviceimpl.deleteStore(id),"deleted");
	}
	
	@Test(expected=StoreNotFoundException.class)
	public void testdeleteStoreWithInvalidId() {
		long id=2L;
		when(storeserviceimpl.deleteStore(id)).thenThrow(new StoreNotFoundException("store cannot be deleted"));
		assertEquals(storeserviceimpl.deleteStore(id),"store cannot be deleted");
	}
	
	
	
}
