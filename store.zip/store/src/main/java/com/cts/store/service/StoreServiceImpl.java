package com.cts.store.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cts.store.entity.Store;
import com.cts.store.repository.StoreRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class StoreServiceImpl implements StoreService{
	@Autowired
	StoreRepository storeRepository;
	@Override
	public String createStore(Store store) {
		// TODO Auto-generated method stub
		log.info("Executing create store with store "+store);
	    storeRepository.save(store);
	    return "store been created";
		//return new ResponseEntity<Object>(store,HttpStatus.OK);
		
	}

	@Override
	public String updateStore(Store store) {
		// TODO Auto-generated method stub
		log.info("Executing update store with store "+store);
		Store st=storeRepository.findById(store.getStoreNumber()).get();
		storeRepository.save(store);
		return "store been updated";
	}

	
	public String deleteStore(Long id) {
		// TODO Auto-generated method stub
		log.info("Executing delete store with id "+id);
		storeRepository.deleteById(id);
		return "store been deleted";
	}

	@Override
	public boolean storeExist(Long id) {
		// TODO Auto-generated method stub
		return storeRepository.existsById(id);
	}


	public List<Store> getAllStores() {
		// TODO Auto-generated method stub
		
		return storeRepository.findAll();
	}

	
}
