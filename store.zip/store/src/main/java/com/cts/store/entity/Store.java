package com.cts.store.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
@Entity
public class Store
{
	@Id
	private Long storeNumber;
	private String storeName;
	private String storePattern;
	private String storeLocation;
	private String state;
	private String city;
	private Long pinCode;
	private String storeOpeningTime;
	private String storeClosingTime;
	
	
	
	
}