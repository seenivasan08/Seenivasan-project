package com.cts.store.controller;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StoreErrorResponse {
	
	private int status;
	private String message;
	private long timeStamp;
	
	public StoreErrorResponse() {
		
	}

	public StoreErrorResponse(int status, String message, long timeStamp) {
		super();
		this.status = status;
		this.message = message;
		this.timeStamp = timeStamp;
	}
	

}
