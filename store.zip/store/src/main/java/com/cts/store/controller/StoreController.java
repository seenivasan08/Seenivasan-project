package com.cts.store.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.store.controller.StoreNotFoundException;
import com.cts.store.controller.StoreNotFoundException;
import com.cts.store.controller.StoreNotFoundException;
import com.cts.store.controller.StoreNotFoundException;
import com.cts.store.entity.Store;
import com.cts.store.service.StoreServiceImpl;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController

@CrossOrigin(origins="http://localhost:4200")
public class StoreController {
	@Autowired
	StoreServiceImpl storeServiceImpl;
	
	@PostMapping("/createStore")
	public String create(@RequestBody Store store) {
		log.info("Post request received for store creation");
		if(store.getStoreNumber()==null||store.getStoreNumber()==0||storeServiceImpl.storeExist(store.getStoreNumber()))
		{
				throw new StoreNotFoundException("Store cannot be created. Please enter the storeNumber");
			//return new ResponseEntity<Object>("Store cannot be created. Please enter the storeNumber",HttpStatus.BAD_REQUEST);
		}
		return storeServiceImpl.createStore(store);
		
		
	}
	
	@PutMapping("/updateStore")
	public String update(@RequestBody Store store) {
		log.info("Put request received for store updation");
		if(store.getStoreNumber()==null||!storeServiceImpl.storeExist(store.getStoreNumber()))
		{
				throw new StoreNotFoundException("Store cannot be updated. storeNumber is not found");
		}
		return storeServiceImpl.updateStore(store);
	}
	
	@DeleteMapping("/deleteStore/{id}")
	public String delete(@PathVariable Long id) {
		log.info("Delete request received for item deletion");
		if(!storeServiceImpl.storeExist(id))
		{
			throw new StoreNotFoundException("Store id is not found - " +id+"."+" So store cannot be deleted");
			
			
		}
		storeServiceImpl.deleteStore(id);
		return "Store deleted";
	}
	@GetMapping("/getAllStore")
	public List<Store> getAllStores(){
		return storeServiceImpl.getAllStores();
		
	}
}
