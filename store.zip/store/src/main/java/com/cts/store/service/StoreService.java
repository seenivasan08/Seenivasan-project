package com.cts.store.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.cts.store.entity.Store;

public interface StoreService {
	public String createStore(Store store);
	public String updateStore(Store store);
	public List<Store> getAllStores();
	public boolean storeExist(Long id);
	

}
