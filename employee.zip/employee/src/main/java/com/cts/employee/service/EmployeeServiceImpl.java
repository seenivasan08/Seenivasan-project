package com.cts.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.employee.entity.Employee;
import com.cts.employee.repository.EmployeeRepository;

import lombok.extern.slf4j.Slf4j;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	@Autowired
	EmployeeRepository employeeRepository;
	@Override
	public String createEmployee(Employee employee) {
		// TODO Auto-generated method stub
		
		employeeRepository.save(employee);
		return "Employee details been created";
	}

	@Override
	public String updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		
		employeeRepository.save(employee);
		return "Employee details been updated";
	}
	
	public String deleteEmployee(Long id) {
		employeeRepository.deleteById(id);
		return "Employee details been deleted";
	}
	
	@Override
	public Employee getEmployeeById(Long id) {
		// TODO Auto-generated method stub
		return employeeRepository.findById(id).get();
	}
	
	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return employeeRepository.findAll();
	}

	


	

}
