package com.cts.employee.service;

import java.util.List;

import com.cts.employee.entity.Employee;

public interface EmployeeService {
	public String createEmployee(Employee employee);
	
	public String updateEmployee(Employee employee);
	

	
	public List<Employee> getAllEmployees();
	
	public Employee getEmployeeById(Long id);
	
	
}
