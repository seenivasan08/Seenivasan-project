package com.storeitemsetup.item.service;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.*;

import org.assertj.core.util.Arrays;
import org.junit.Test;
import org.yaml.snakeyaml.events.Event.ID;

import com.cts.item.controller.ItemNotFoundException;
import com.cts.item.entity.Item;
import com.cts.item.service.ItemServiceImpl;

import antlr.collections.List;


public class ItemServiceImplTest {

	ItemServiceImpl itemserviceimpl = mock(ItemServiceImpl.class);
	
	
	@Test
	public void testcreateItemWithItem() {
		Item item = new Item();
		item.setItemNumber(1L);
		item.setItemName("Boost");
		item.setItemType("B01");
		item.setPrice(10.00);
		item.setStoreName("Favorite Store");
		Date d1=new Date(2022,10,17);
		item.setStartDate(d1);
		Date d2=new Date(2022,10,17);
		item.setEndDate(d2);
		when(itemserviceimpl.createItem(item)).thenReturn("created");
		assertEquals(itemserviceimpl.createItem(item),"created");
	}
	
	@Test(expected=ItemNotFoundException.class)
	public void testcreateItemWithNull() {
		Item it = null;
		when(itemserviceimpl.createItem(it)).thenThrow(new ItemNotFoundException("item cannot be created"));
		assertEquals(itemserviceimpl.createItem(it),"item cannot be created");
	}
	
	@Test
	public void testupdateItemWithItem() {
		Item item = new Item();
		item.setItemNumber(1L);
		item.setItemName("Boost");
		item.setItemType("B01");
		item.setPrice(10.00);
		item.setStoreName("Favorite Store");
		Date d1=new Date(2022,10,17);
		item.setStartDate(d1);
		Date d2=new Date(2022,10,17);
		item.setEndDate(d2);
		when(itemserviceimpl.updateItem(item)).thenReturn("updated");
		assertEquals(itemserviceimpl.updateItem(item),"updated");
	}
	@Test(expected=ItemNotFoundException.class)
	public void testupdateItemWithNull() {
		Item it=null;
		when(itemserviceimpl.updateItem(it)).thenThrow(new ItemNotFoundException("item cannot be updated"));
		assertEquals(itemserviceimpl.updateItem(it),"item cannot be created");
	}
	@Test(expected=ItemNotFoundException.class)
	public void testupdateItemWithInvalidId() {
		Item it=new Item();
		it.setItemNumber(2L);
		when(itemserviceimpl.updateItem(it)).thenThrow(new ItemNotFoundException("item cannot be updated"));
		assertEquals(itemserviceimpl.updateItem(it),"item cannot be updated");
	}
	
	@Test
	public void testdeleteItemWithItem() {
	    long id=1L;
		when(itemserviceimpl.deleteItem(id)).thenReturn("deleted");
		assertEquals(itemserviceimpl.deleteItem(id),"deleted");
	}
	
	@Test(expected=ItemNotFoundException.class)
	public void testdeleteItemWithInvalidId() {
		long id=2L;
		when(itemserviceimpl.deleteItem(id)).thenThrow(new ItemNotFoundException("item cannot be deleted"));
		assertEquals(itemserviceimpl.deleteItem(id),"item cannot be deleted");
	}
	
	@Test
	public void testgetItemByIdWithItem() {

		Item it=new Item();
		it.setItemNumber(2L);
		it.setItemName("Horlicks");
		it.setItemType("S02");
		it.setPrice(12.00);
		it.setStoreName("Favorite Store");
		Date d1=new Date(2022,01,12);
		it.setStartDate(d1);
		Date d2=new Date(2022,01,12);
		it.setEndDate(d2);
		
		when(itemserviceimpl.getItemById(2L)).thenReturn(it);
		assertEquals(itemserviceimpl.getItemById(2L),it);
	}
	
	@Test(expected=ItemNotFoundException.class)
	public void testgetItemByInvalidIdWithItem() {
		long id=2L;
		when(itemserviceimpl.getItemById(id)).thenThrow(new ItemNotFoundException("itemNumber is not found"));
		assertEquals(itemserviceimpl.getItemById(id),"itemNumber is not found");
	}

	@Test
	public void testgetItemByNamewithItem() {
		Item it=new Item();
		it.setItemNumber(2L);
		it.setItemName("Horlicks");
		it.setItemType("S02");
		it.setPrice(12.00);
		it.setStoreName("Favorite Store");
		Date d1=new Date(2022,01,12);
		it.setStartDate(d1);
		Date d2=new Date(2022,01,12);
		it.setEndDate(d2);
		
		when(itemserviceimpl.getItemByName("Horlicks")).thenReturn(it);
		assertEquals(itemserviceimpl.getItemByName("Horlicks"),it);
	}
	
	@Test(expected=ItemNotFoundException.class)
	public void testgetItemByInvalidNameWithItem() {
		String name="Horlicks";
		when(itemserviceimpl.getItemByName(name)).thenThrow(new ItemNotFoundException("itemName is not found"));
		assertEquals(itemserviceimpl.getItemByName(name),"itemName is not found");
	}
	
	
	

}
