package com.cts.item.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
@Entity
public class Item {

	@Id
	private Long itemNumber;
	private String itemName;
	private String itemType;
	private Double price;
	private String storeName;
	@Temporal(value=TemporalType.DATE)
	private Date startDate;
	@Temporal(value=TemporalType.DATE)
	private Date endDate;
 
	

}
