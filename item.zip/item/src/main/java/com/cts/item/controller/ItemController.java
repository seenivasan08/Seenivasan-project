package com.cts.item.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.item.entity.Item;
import com.cts.item.service.ItemServiceImpl;
import com.cts.item.entity.Item;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@CrossOrigin(origins="http://localhost:4200")
public class ItemController {
	@Autowired
	ItemServiceImpl itemServiceImpl;
	
	
	@PostMapping("/createItem")
	public String create(@RequestBody Item item) {
		log.info("Post request received for item creation");
		if(item.getItemNumber()==null||item.getItemNumber()==0||itemServiceImpl.itemExist(item.getItemNumber()))
		{
				throw new ItemNotFoundException("Item cannot be created. Please enter the item number");
		}
		return itemServiceImpl.createItem(item);
	
	}
	
	@PutMapping("/updateItem")
	public String update(@RequestBody Item item) {
		log.info("Put request received for store updation");
		if(item.getItemNumber()==null||!itemServiceImpl.itemExist(item.getItemNumber()))
		{
				throw new ItemNotFoundException("Item cannot be updated. itemNumber is not found");
		}
         return itemServiceImpl.updateItem(item);
         
	}
	
	
	@DeleteMapping("/deleteItem/{id}")
	public String delete(@PathVariable Long id) {
		log.info("Delete request received for item deletion");
		if(!itemServiceImpl.itemExist(id))
		{
			throw new ItemNotFoundException("Item id is not found - " +id+"."+" So Item cannot be deleted");
			
			
		}
		itemServiceImpl.deleteItem(id);
		return "Item been deleted";
	}
	
	@GetMapping("/item/id/{id}")
	public Item getById(@PathVariable Long id) {
		
		log.info("Get request received for getting item");
		if(!itemServiceImpl.itemExist(id)) {
			throw new ItemNotFoundException("Item id not found - " + id+"." + "There is no item in the store");
		}
		
		return itemServiceImpl.getItemById(id);
		
	}
	
	
	
	@GetMapping("/item/name/{name}")
	public Item getByName(@PathVariable String name) {
		log.info("Get request received for getting name");
	    if(!itemServiceImpl.itemExist(name)) {
	    	throw new ItemNotFoundException("Item name is not found - "+ name+"." + "There is no item in the store");
	    }
		return itemServiceImpl.getItemByName(name);
		
	}
	@GetMapping("/getAllItem")
	public List<Item> getAllItems(){
		return itemServiceImpl.getAllItems();
		
	}
	

}
