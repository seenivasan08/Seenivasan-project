package com.cts.item.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.item.controller.ItemNotFoundException;
import com.cts.item.entity.Item;
import com.cts.item.repository.ItemRepository;


import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ItemServiceImpl implements ItemService{
	@Autowired
	ItemRepository itemRepository;
	@Override
	public String createItem(Item item) {
		// TODO Auto-generated method stub
		log.info("Executing create item with item "+item);
		itemRepository.save(item);
		return "Item been created";
		
			
	}

	@Override
	public String updateItem(Item item) {
		// TODO Auto-generated method stub
		log.info("Executing update store with store "+item);
		Item it=itemRepository.findById(item.getItemNumber()).get();
		itemRepository.save(item);
		return "Item been updated";
		
			
		}
		
	
	
	public String deleteItem(Long id){
		// TODO Auto-generated method stub
		log.info("Executing delete item with id "+id);
		
		itemRepository.deleteById(id);
		
		return "item been deleted";
		
	}

	@Override
	public Item getItemById(Long id) {
		// TODO Auto-generated method stub
		log.info("Getting item with id "+id);
		 return itemRepository.findById(id).get();
		 
		
	}

	@Override
	public Item getItemByName(String name) {
		// TODO Auto-generated method stub
		log.info("Getting item with name "+name);
		 return itemRepository.findByItemName(name);
		 
	}

	@Override
	public boolean itemExist(Long id) {
		// TODO Auto-generated method stub
		
		return itemRepository.existsById(id);
	}

	@Override
	public boolean itemExist(String name) {
		// TODO Auto-generated method stub
		return itemRepository.existsByItemName(name);
	}

	@Override
	public List<Item> getAllItems() {
		// TODO Auto-generated method stub
		return itemRepository.findAll();
	}



}
