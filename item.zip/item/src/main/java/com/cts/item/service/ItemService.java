package com.cts.item.service;

import java.util.List;

import com.cts.item.entity.Item;
import com.cts.item.entity.Item;


public interface ItemService {
	public String createItem(Item item);
	public String updateItem(Item item);
	public List<Item> getAllItems();
	
	public Item getItemById(Long id);
	public Item getItemByName(String name);
	
	public boolean itemExist(Long id);
	public boolean itemExist(String name);
	
	
}
