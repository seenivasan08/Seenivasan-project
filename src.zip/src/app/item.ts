export class Item {
    itemNumber: number;
    itemName: String;
    itemType: String;
    price: String;
    storeName: String;
    startDate: Date;
    endDate: Date;
}
