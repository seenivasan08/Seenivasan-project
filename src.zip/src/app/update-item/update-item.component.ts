import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { ItemService } from '../item.service';

@Component({
  selector: 'app-update-item',
  templateUrl: './update-item.component.html',
  styleUrls: ['./update-item.component.css']
})
export class UpdateItemComponent implements OnInit {

  updateForm: FormGroup
  submitted = false;
  isDisabled = true;
  constructor(private itemService: ItemService,private fb: FormBuilder, private router: Router) {
    this.updateForm = this.fb.group({
      itemNumber: this.fb.control(''),
      itemName: this.fb.control('', Validators.required),
      itemType: this.fb.control('', Validators.required),
      price: this.fb.control('', Validators.required),
      storeName: this.fb.control('', Validators.required),
      startDate: this.fb.control('', Validators.required),
      endDate: this.fb.control('', Validators.required),
    

      // hours: this.fb.control('', Validators.required)
    })
   }

  ngOnInit(): void {
  }
  
  onSubmit() {
    if (this.updateForm.valid) {
      this.itemService.updateItem(this.updateForm.value).subscribe(data => {
        console.log(data);
        Swal.fire('Success!','Item details been updated', 'success')
        // this.gotoList();
      },
      error=>{console.log(error.error);
        Swal.fire('Error!','Item details cannot be updated', 'error');
        // this.gotoList();
      }
      
      );
    } else {
      // this.msg=true;
      window.alert("please fill all required field");
    }
}

}
