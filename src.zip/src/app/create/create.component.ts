import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { StoreService } from 'src/service/store.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {

  storeForm: FormGroup
  submitted = false;
  constructor(private storeService: StoreService,private fb: FormBuilder, private router: Router) {
    this.storeForm = this.fb.group({
      storeNumber: this.fb.control('', Validators.required),
      storeName: this.fb.control('', Validators.required),
      storePattern: this.fb.control('', Validators.required),
      storeLocation: this.fb.control('', Validators.required),
      state: this.fb.control('', Validators.required),
      city: this.fb.control('', Validators.required),
      pinCode: this.fb.control('', Validators.required),
      storeOpeningTime: this.fb.control('', Validators.required),
      storeClosingTime: this.fb.control('', Validators.required)
    })
   }
  ngOnInit(): void {
  }
  onSubmit() {
    if (this.storeForm.valid) {
      this.storeService.createStore(this.storeForm.value).subscribe(data => {
        console.log(data);
        Swal.fire('Success!', 'Store been created', 'success')
        // this.gotoList();
      },
      error=>{console.log(error.error);
        Swal.fire('Invalid!','store cannot be created', 'warning');
        // this.gotoList();
      });
    } else {
      // this.msg=true;
      window.alert("please fill all required field");
    }
}
}
