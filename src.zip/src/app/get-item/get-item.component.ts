import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { Item } from '../item';
import { ItemService } from '../item.service';

@Component({
  selector: 'app-get-item',
  templateUrl: './get-item.component.html',
  styleUrls: ['./get-item.component.css']
})
export class GetItemComponent implements OnInit {
 
  items: any;
  getForm: FormGroup
  submitted = false;
  itemNumber:number;
  itemName:String;
  constructor(private itemService: ItemService,private fb: FormBuilder, private router: Router) {
    this.getForm = this.fb.group({
      itemNumber: this.fb.control(''),
      itemName: this.fb.control('')
    })
   }

  ngOnInit(): void {
  
  }
 
  onSubmit() {
    //this.number=this.deleteForm.value[1]
    console.log(this.getForm.value.itemNumber)
    console.log(this.getForm.value.itemName)
    if (this.getForm.valid) {
      this.itemService.getItem(this.getForm.value.itemNumber).subscribe(data => {
        console.log(data);
        this.items=data;
        Swal.fire('Success!','Item been found', 'success')
       
        // this.gotoList();
      },
      error=>{console.log(error.error);
        Swal.fire('Error!','Cannot able to fetch', 'error');
        // this.gotoList();
      }
      
      );
    }
    // else {
    //   // this.msg=true;
    //   window.alert("please fill all required field");
    // }
    if (this.getForm.valid) {
      this.itemService.getByName(this.getForm.value.itemName).subscribe(data => {
        console.log(data);
        this.items=data;
        Swal.fire('Success!','Item been found', 'success')
       
        // this.gotoList();
      },
      error=>{console.log(error.error);
        Swal.fire('Error!','Cannot able to fetch', 'error');
        // this.gotoList();
      }
      
      );
    }
  
    }
     
    

}





