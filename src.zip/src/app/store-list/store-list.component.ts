import { Component, OnInit } from '@angular/core';
import { StoreService } from 'src/service/store.service';
import { Store } from '../store';
@Component({
  selector: 'app-store-list',
  templateUrl: './store-list.component.html',
  styleUrls: ['./store-list.component.css']
})
export class StoreListComponent implements OnInit {

  stores: Store[];
  constructor(private storeService:StoreService) { }

  ngOnInit(): void {
    this.getStores();
  }
  private getStores(){
    this.storeService.getAllStores().subscribe(data => {
      this.stores = data;
    });

}
}
