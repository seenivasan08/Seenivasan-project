import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Item } from './item';

@Injectable({
  providedIn: 'root'
})
export class ItemService {

  private baseUrl= "http://localhost:8101"
  private baseUrl1="http://localhost:8000"
  constructor(private http: HttpClient) { }
  getAllItems(): Observable<Item[]>{
    return this.http.get<Item[]>(`${this.baseUrl}/getAllItem`);
  }
  createItem(itemDetail: object): Observable<any> {
    return this.http.post(`${this.baseUrl}/createItem`, itemDetail,{responseType:'text'});
  }
  updateItem(itemDetail: object): Observable<any> {
    return this.http.put(`${this.baseUrl}/updateItem`, itemDetail,{responseType:'text'});
  }
  deleteItem(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/deleteItem/${id}`,{responseType:'text'});
  }
  getItem(id: number): Observable<Item> {
    return this.http.get<Item>(`${this.baseUrl1}/item/id/${id}`);
  }

  getByName(itemName: String): Observable<Item> {
    return this.http.get<Item>(`${this.baseUrl1}/item/name/${itemName}`);
  }

 
 
 
  
}
