import { Component, OnInit } from '@angular/core';
import { ControlContainer, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { StoreService } from 'src/service/store.service';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  updateForm: FormGroup
  submitted = false;
  isDisabled = true;
  constructor(private storeService: StoreService,private fb: FormBuilder, private router: Router) {
    this.updateForm = this.fb.group({
      storeNumber: this.fb.control(''),
      storeName: this.fb.control('', Validators.required),
      storePattern: this.fb.control('', Validators.required),
      storeLocation: this.fb.control('', Validators.required),
      state: this.fb.control('', Validators.required),
      city: this.fb.control('', Validators.required),
      pinCode: this.fb.control('', Validators.required),
      storeOpeningTime: this.fb.control('', Validators.required),
      storeClosingTime: this.fb.control('', Validators.required)
      

      // hours: this.fb.control('', Validators.required)
    })
   }

  ngOnInit(): void {
  }
  
  onSubmit() {
    if (this.updateForm.valid) {
      this.storeService.updateStore(this.updateForm.value).subscribe(data => {
        console.log(data);
        Swal.fire('Success!', 'Store been updated', 'success')
        // this.gotoList();
      },
      error=>{console.log(error.error);
        Swal.fire('Error!','Store details cannot be updated', 'error');
        // this.gotoList();
      }
      
      );
    } else {
      // this.msg=true;
      window.alert("please fill all required field");
    }
}
}
