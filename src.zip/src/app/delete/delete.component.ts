import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { StoreService } from 'src/service/store.service';
import Swal from 'sweetalert2';
import { Item } from '../item';

@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {

    deleteForm: FormGroup
    submitted = false;
    storeNumber:number;
  
    constructor(private storeService: StoreService,private fb: FormBuilder, private router: Router) {
      this.deleteForm = this.fb.group({
        storeNumber: this.fb.control('', Validators.required),
      
        
  
        // hours: this.fb.control('', Validators.required)
      })
     }
  
    ngOnInit(): void {
    }
    // deleteStore(id: number) {
    //   this.storeService.deleteStore(id)
    //     .subscribe(
    //       data => {
    //         console.log(data);

    //       },
    //       error => console.log(error));
    // }

    
 
    // save() {
    //   this.employeeService.createEmployee(this.employee).subscribe(data => {
    //     console.log(data)
    //     this.employee = new Employee();
    //     this.gotoList();
    //   },
    //     error => console.log(error));
    // }
    onSubmit() {
      //this.number=this.deleteForm.value[1]
      console.log(this.deleteForm.value.storeNumber)
      if (this.deleteForm.valid) {
        this.storeService.deleteStore(this.deleteForm.value.storeNumber).subscribe(data => {
          console.log(data);
          Swal.fire('Success!','Store been deleted', 'success')
          // this.gotoList();
        },
        error=>{console.log(error.error);
          Swal.fire('Error!','store details cannot be deleted', 'error');
          // this.gotoList();
        }
        
        );
      } else {
        // this.msg=true;
        window.alert("please fill all required field");
      }
    // // gotoList() {
    //   this.router.navigate(['/employees']);
    // }
  
    // newEmployee(): void {
    //   this.submitted = false;
    //   this.employee = new Employee();
    // }
  }
  }
  

