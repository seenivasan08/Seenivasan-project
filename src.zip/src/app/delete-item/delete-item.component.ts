import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { ItemService } from '../item.service';

@Component({
  selector: 'app-delete-item',
  templateUrl: './delete-item.component.html',
  styleUrls: ['./delete-item.component.css']
})
export class DeleteItemComponent implements OnInit {

  deleteForm: FormGroup
  submitted = false;
  itemNumber:number;
  constructor(private itemService: ItemService,private fb: FormBuilder, private router: Router) {
    this.deleteForm = this.fb.group({
      itemNumber: this.fb.control('', Validators.required),
    })
   }

  ngOnInit(): void {
  }
 
  onSubmit() {
    //this.number=this.deleteForm.value[1]
    console.log(this.deleteForm.value.itemNumber)
    if (this.deleteForm.valid) {
      this.itemService.deleteItem(this.deleteForm.value.itemNumber).subscribe(data => {
        console.log(data);
        Swal.fire('Success!','Item been deleted', 'success')
        // this.gotoList();
      },
      error=>{console.log(error.error);
        Swal.fire('Error!','Item details cannot be deleted', 'error');
        // this.gotoList();
      }
      
      );
    } else {
      // this.msg=true;
      window.alert("please fill all required field");
    }
}

}
