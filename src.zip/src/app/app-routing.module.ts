import { createComponent, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreateItemComponent } from './create-item/create-item.component';
import { CreateComponent } from './create/create.component';
import { DeleteItemComponent } from './delete-item/delete-item.component';
import { DeleteComponent } from './delete/delete.component';
import { GetItemComponent } from './get-item/get-item.component';

import { ItemListComponent } from './item-list/item-list.component';


import { StoreListComponent } from './store-list/store-list.component';
import { UpdateItemComponent } from './update-item/update-item.component';
import { UpdateComponent } from './update/update.component';
const routes: Routes = [
  { path: '', redirectTo: 'create', pathMatch: 'full' },
  {path: 'stores', component: StoreListComponent},
  { path: 'create', component: CreateComponent },
  { path: 'update', component: UpdateComponent },
  {path: 'delete', component: DeleteComponent},
  {path: 'items', component:ItemListComponent},
  {path: 'create-item', component:CreateItemComponent},
  {path: 'update-item', component:UpdateItemComponent},
  {path: 'delete-item', component:DeleteItemComponent},
  {path: 'get-item', component:GetItemComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
