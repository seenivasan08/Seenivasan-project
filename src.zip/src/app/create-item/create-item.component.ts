import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { ItemService } from '../item.service';

@Component({
  selector: 'app-create-item',
  templateUrl: './create-item.component.html',
  styleUrls: ['./create-item.component.css']
})
export class CreateItemComponent implements OnInit {
  itemForm: FormGroup
  submitted = false;
  constructor(private itemService: ItemService,private fb: FormBuilder, private router: Router) {
    this.itemForm = this.fb.group({
      itemNumber: this.fb.control('', Validators.required),
      itemName: this.fb.control('', Validators.required),
      itemType: this.fb.control('', Validators.required),
      price: this.fb.control('', Validators.required),
      storeName: this.fb.control('', Validators.required),
      startDate: this.fb.control('', Validators.required),
      endDate: this.fb.control('', Validators.required),
    
    })
   }
  ngOnInit(): void {
  }
  onSubmit() {
    if (this.itemForm.valid) {
      this.itemService.createItem(this.itemForm.value).subscribe(data => {
        console.log(data);
        Swal.fire('Success!', 'Item been created', 'success')
        // this.gotoList();
      },
      error=>{console.log(error.error);
        Swal.fire('Invalid!','Item cannot be created', 'warning');
        // this.gotoList();
      });
    } else {
      // this.msg=true;
      window.alert("please fill all required field");
    }
}

}
