 export class Store {
  storeNumber: number;
  storeName: string;
  storePattern: string;
  storeLocation: string;
  state: string;
  city: string;
  pinCode: number;
  storeOpeningTime: string;
  storeClosingTime: string; 
 }
